<?php

require_once "../JentiConfig.php";
require_once "../JentiCrawler.php";

$config["cache_on"] = false;
//$config["default_source"] = "Wiktionary";
$config["default_source"] = "Wikizionario";
/*
$words_array = explode(PHP_EOL, "bee
hive
account
act
addition
adjustment
advertisement
agreement
air
amount
amusement
animal
answer
apparatus
approval
argument
art
attack
attempt
mind
mine
minute
mist
money
month
morning
mother
motion
mountain
move
music
name
nation
need
news");
*/

$words_array = array("guerra");

$crawler = new JentiCrawler($config);
$crawler->crawl($words_array);