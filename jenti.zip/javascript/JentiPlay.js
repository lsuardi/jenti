
$(document).ready(function() 
{
    $("#button-play").click(function(event) 
    {
        var catalog = jQuery.data(document.body, "catalog");
        $.ajax({
            url: "ajax/get_next_word.php",
            //data: {
            //id: 123
            //},
            type: "GET",
            dataType : "json",
            success: function(json) 
            {
                var word = json.WORD;
                var definition = json.DEFINITION;
                $("#div-content").html(catalog[0] + " = " + definition);
            },
            error: function(xhr, status, errorThrown) 
            {
                var msg = "Error: " + errorThrown
                        + "Status: " + status
                        ;
                $("#span-footer").text(msg);
            }
        });
    });
});   
