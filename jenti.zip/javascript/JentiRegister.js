
$(document).ready(function() 
{
    $("#button-register").click(function(event) 
    {
        alert("Register!");
        /*
        $.ajax({
            url: "http://192.168.2.9:88/php/jenti/ajax/get_next_word.php",
            //data: {
            //id: 123
            //},
            type: "GET",
            dataType : "json",
            success: function(json) 
            {
                var word = json.WORD;
                var definition = json.DEFINITION;
                $("#p-definition").text(definition);
                $("#p-word").text(word);
            },
            error: function(xhr, status, errorThrown) 
            {
                var msg = "Error: " + errorThrown
                        + "Status: " + status
                        ;
                $("#p-definition").text(msg);
            },
            complete: function(xhr, status) 
            {
                //alert("The request is complete!");
            }
        });
        */
    });
});   
