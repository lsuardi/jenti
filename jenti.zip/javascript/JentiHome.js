
// Copyright 2015 - NINETY-DEGREES

$(document).ready(function() 
{
    var catalog = jQuery.data(document.body, "catalog");
    if (!catalog)
    {
        $.ajax({
            url: "ajax/get_catalog.php",
            type: "GET",
            dataType : "json",
            success: function(json) 
            {
                // save catalog
                jQuery.data(document.body, "catalog", json);
                
                // render home page
                render_home();
            },
            error: function(xhr, status, errorThrown) 
            {
                render_error(status + " - " + errorThrown);
            }
        });
    }
}); 



function render_error(msg)
{
    //$("#span-footer").text(msg);
    alert(msg);
}



function render_home()
{
    var catalog = jQuery.data(document.body, "catalog");
    var showCount;
    var score;

    $("#div-content").html(html_home());

    $("#button-play").click(function(event) 
    {
        $.ajax({
            url: "ajax/get_next_word.php",
            type: "GET",
            dataType : "json",
            success: function(json) 
            {
                if (json.hasOwnProperty("ERROR"))
                {
                    render_error(json.ERROR); 
                    return;
                }

                // display word data
                var word = json.WORD;
                var definition = json.DEFINITION;
                var wordTip = word.length + " " + catalog[10];
                $("#p-definition").text(definition);
                $("#input-word").val(wordTip);
                $("#p-hint-popup-content").html(html_hint_popup(json));
                $("#button-hint").removeClass("ui-disabled");
                $("#button-guess").removeClass("ui-disabled");
                $("#button-show").removeClass("ui-disabled");
                $("#p-score").text(html_score());
                $("#button-feedback").removeClass("ui-disabled");
                
                // save word data
                jQuery.data(document.body, "word_json", json);
                
                // initialize play
                showCount = 0;
                score = word.length;
            },
            error: function(xhr, status, errorThrown) 
            {
                render_error(status + " - " + errorThrown);
            }
        });
    });

    $("#input-word").click(function(event)
    {
        var word_json = jQuery.data(document.body, "word_json");
        var word = word_json.WORD;
        var inputWord = "";
        if (showCount > 0)
        {
            inputWord = word.substring(0, showCount);
        }
        $("#input-word").val(inputWord);
    });

    $("#button-guess").click(function(event) 
    {
        var word_json = jQuery.data(document.body, "word_json");
        var word = word_json.WORD;
        var guess = $("#input-word").val();
        $("#p-guess-popup-content").html(html_guess_popup(word_json, guess));
        if (guess.toUpperCase() === word.toUpperCase())
        {
            showCount = word.length;
            
            // save score and other info
            $.ajax({
                url: "ajax/post_guess.php",
                data: {
                    WORD_ID: word_json.WORD_ID,
                    DEFINITION_ID: word_json.ID,
                    SCORE: score
                },
                type: "POST",
                dataType : "json",
                success: function(json) 
                {
                    if (json.hasOwnProperty("ERROR"))
                    {
                        render_error(JSON.stringify(json,null,2)); 
                        return;
                    }
                    $("#p-score").text(html_score());
                },
                error: function(xhr, status, errorThrown) 
                {
                    var msg = "Error: " + errorThrown
                            + "Status: " + status
                            ;
                    $("#span-footer").text(msg);
                }
            });
        }
    });

    $("#button-show").click(function(event) 
    {
        var word_json = jQuery.data(document.body, "word_json");
        var word = word_json.WORD;
        
        showCount++;

        var inputWord = word.substring(0, showCount);
        for (i=showCount; i<word.length; i++)
        {
            inputWord += " -";
        }
        
        score--;
        
        $("#input-word").val(inputWord);

        if (showCount == word.length)
        {
            $("#button-show").addClass("ui-disabled");            
        }
    });
}



function render_options()
{
    var catalog = jQuery.data(document.body, "catalog");
    
    var html 
        = '<button id="button-play" class="ui-btn ui-corner-all">' + catalog[1] + '</button>\n'
        + '<button id="button-login" class="ui-btn ui-corner-all">' + catalog[2] + '</button>\n'
        + '<button id="button-language" class="ui-btn ui-corner-all">' + catalog[3] + '</button>\n'
        + '<button id="button-about" class="ui-btn ui-corner-all">' + catalog[4] + '</button>\n'
        ;
    
    $("#div-content").html(html);

    $("#button-play").click(function(event) 
    {
        $.ajax({
            url: "ajax/get_next_word.php",
            //data: {
            //id: 123
            //},
            type: "GET",
            dataType : "json",
            success: function(json) 
            {
                var word = json.WORD;
                var definition = json.DEFINITION;
                $("#div-content").html(catalog[0] + " = " + definition);
            },
            error: function(xhr, status, errorThrown) 
            {
                render_error(status + " - " + errorThrown);
            }
        });
    });
}