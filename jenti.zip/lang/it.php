<?php

// Copyright 2015 NINETY_DEGREES

///////////////////////////////////////////////////////////////////////////
////////// LANGUAGE CATALOG - ITALIAN                            ////////// 
///////////////////////////////////////////////////////////////////////////

$catalog[0]   = "J E N T I";
$catalog[1]   = "Gioca";
$catalog[2]   = "Accedi";
$catalog[3]   = "Lingua";
$catalog[4]   = "Informazioni";
$catalog[5]   = "Gioca e Impara";
$catalog[6]   = "Clicca gioca per cominciare...";
$catalog[7]   = "Definizione";
$catalog[8]   = "Aiuto";
$catalog[9]   = "Indovina";
$catalog[10]  = "caratteri";
$catalog[11]  = "Chiudi";
$catalog[12]  = "La parola e` di tipo";
$catalog[13]  = "Ci sono definizioni alternative:";
$catalog[14]  = "Riprova !";
$catalog[15]  = "Bravo, la parola e`";
$catalog[16]  = "Gioca ancora !";
$catalog[17]  = "Suggerisci";
$catalog[18]  = "Mostra";
$catalog[19]  = "Suggerimento";
$catalog[20]  = "Invia il tuo suggerimento.";
$catalog[21]  = "Invia";
$catalog[22]  = "La definizione e` presa da";
$catalog[23]  = "Punti";
$catalog[24]  = "Categorie:";



?>