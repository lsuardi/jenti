<?php

// Copyright 2015 NINETY_DEGREES

///////////////////////////////////////////////////////////////////////////
////////// LANGUAGE CATALOG - ENGLISH                            ////////// 
///////////////////////////////////////////////////////////////////////////

$catalog[0]   = "Jenti";
$catalog[1]   = "Play";
$catalog[2]   = "Login";
$catalog[3]   = "Language";
$catalog[4]   = "About";
$catalog[5]   = "Play & Learn";
$catalog[6]   = "Click play to start playing Jenti...";
$catalog[7]   = "Definition";
$catalog[8]   = "Hint";
$catalog[9]   = "Guess";
$catalog[10]  = "letters";
$catalog[11]  = "Close";
$catalog[12]  = "Word type is ";
$catalog[13]  = "These are alternate definitions:";
$catalog[14]  = "Try again !";
$catalog[15]  = "Bravo, the word is ";
$catalog[16]  = "Play again !";
$catalog[17]  = "Feedback";
$catalog[18]  = "Show";
$catalog[19]  = "Feedback";
$catalog[20]  = "Send your feedback.";
$catalog[21]  = "Send";
$catalog[22]  = "The definition is from ";
$catalog[23]  = "Points ";


?>