<?php

require_once "../JentiConfig.php";
require_once "../JentiSession.php";
require_once "../JentiWord.php";
require_once "../JentiAjax.php";

ini_set('error_reporting', 0);

$session = new JentiSession($config);
if($session->error)
{
    echo ajax_json_response_error($session->error);
    exit;
}

$activity_info["WORD_ID"] = $_REQUEST["WORD_ID"];
$activity_info["DEFINITION_ID"] = $_REQUEST["DEFINITION_ID"];
$activity_info["FEEDBACK"] = $_REQUEST["FEEDBACK"];

$session->save_user_feedback($activity_info);
if($session->error)
{
    echo ajax_json_response_error($session->error);
    exit;
}

echo ajax_json_response("");
