<?php

require_once 'JentiConfig.php';
require_once 'JentiSession.php';

$session = new JentiSession($config);
if($session->error)
{
    echo $session->error;
}

$session->login('eliasuardi@gmail.com', 'houston77077');
if($session->error)
{
    echo 'LOGIN: '.$session->error;
}
else
{
    echo "LOGGED IN";
}
